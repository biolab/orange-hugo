import numpy as np

print(in_data[:3])
print(in_object[:3])

movies_id_top = in_object.X[:,0]
movies_id_big = in_data.X[:,0]

print(movies_id_top[:3])
print(movies_id_big[:3])

mask = np.in1d(movies_id_big, movies_id_top)
print(mask)
indices_match_big = np.where(mask)[0]
print(indices_match_big)

out_data = in_data[indices_match_big]
print(out_data)
