import copy

out_data = copy.deepcopy(in_data)
out_data.X[:, :2] -= 1