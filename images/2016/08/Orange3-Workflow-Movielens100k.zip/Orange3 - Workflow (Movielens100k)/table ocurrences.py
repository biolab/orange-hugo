from Orange.data import Domain, ContinuousVariable, Table
from collections import Counter
import numpy as np

TOP_MOVIES = 3
movies_pop = in_data.X[:, 1]

occ = Counter(movies_pop).most_common(TOP_MOVIES)
print(occ)

X = np.asarray(list(zip(*occ))).T
print(X[:TOP_MOVIES])


domain = Domain([ContinuousVariable.make("Movie id"),
                ContinuousVariable.make("Frequency")])
                
out_data = Table.from_numpy(domain, X)
print(out_data[:3])
